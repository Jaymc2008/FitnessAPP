import 'package:flutter/material.dart';

class MyColor {
  static const Color primary = Color(0xff156C78);
  static const Color secondary = Color(0xffFB784E);
}